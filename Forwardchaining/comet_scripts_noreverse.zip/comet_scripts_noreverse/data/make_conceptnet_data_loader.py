#xxx = open("suboprocess_logging.txt", "w", buffering=1)

import os
import sys
# added by katha
from argparse import ArgumentParser

sys.path.append(os.getcwd())

import torch
import src_noreverse.data.conceptnet as cdata
import src_noreverse.data.data as data

from utils_noreverse.utils import DD
import utils_noreverse.utils as utils
import random
from src_noreverse.data.utils import TextEncoder
from tqdm import tqdm

#xxx.write("1\n")

# added by katha
parser = ArgumentParser(description='generate concepts with COMET for IKAT dataset')
parser.add_argument('--data_path',
                    required=True,
                    dest='data_path',
                    help='Path where the train, dev and test data are located and to be loaded from.')
parser.add_argument('--save_path',
                    required=True,
                    dest='save_path',
                    help='Path where data will be saved to to be used with the generator.') 
args = parser.parse_args()

opt = DD()
opt.dataset = "conceptnet"
opt.exp = "generation"

opt.data = DD()

# Use relation embeddings rather than
# splitting relations into its component words
# Set to "language" for using component words
# Set to "relation" to use unlearned relation embeddings
opt.data.rel = "language"

# Use 100k training set
opt.data.trainsize = 100

# Use both dev sets (v1 an v2)
opt.data.devversion = "12"

# Maximum token length of e1
opt.data.maxe1 = 10

# Maximum token length of e2
opt.data.maxe2 = 15

relations = [
    'AtLocation', 'CapableOf', 'Causes', 'CausesDesire', 'CreatedBy',
    'DefinedAs', 'DesireOf', 'Desires', 'HasA', 'HasFirstSubevent',
    'HasLastSubevent', 'HasPainCharacter', 'HasPainIntensity',
    'HasPrerequisite', 'HasProperty', 'HasSubevent', 'InheritsFrom',
    'InstanceOf', 'IsA', 'LocatedNear', 'LocationOfAction', 'MadeOf',
    'MotivatedByGoal', 'NotCapableOf', 'NotDesires', 'NotHasA',
    'NotHasProperty', 'NotIsA', 'NotMadeOf', 'PartOf', 'ReceivesAction',
    'RelatedTo', 'SymbolOf', 'UsedFor'
]

special = [data.start_token, data.end_token]
special += ["<{}>".format(relation) for relation in relations]

# path changed for integration of reverse/not reverse
encoder_path = "model_noreverse/encoder_bpe_40000.json"
bpe_path = "model_noreverse/vocab_40000.bpe"

#xxx.write("2\n")
##xxx.flush()

text_encoder = TextEncoder(encoder_path, bpe_path)

#xxx.write("3\n")
#xxx.flush()

for special_token in special:
    text_encoder.decoder[len(text_encoder.encoder)] = special_token
    text_encoder.encoder[special_token] = len(text_encoder.encoder)

#xxx.write("4\n")
#xxx.flush()
    
data_loader = cdata.GenerationDataLoader(opt)
# changed by katha
data_loader.load_data(args.data_path)
#data_loader.load_data("data/conceptnet/")

#xxx.write("5\n")
#xxx.flush()

### added by katha
print('\n#### LOADED DATA')
print('#### MAKING TENSORS')

data_loader.make_tensors(text_encoder, special, test=False)

#xxx.write("6\n")
#xxx.flush()

opt.data.maxr = data_loader.max_r

#save_path = "data/conceptnet/processed/generation"
# changed by katha
save_path = args.save_path
save_name = os.path.join(save_path, "{}.pickle".format(
    utils.make_name_string(opt.data)))

#xxx.write("7\n")
#xxx.flush()

utils.mkpath(save_path)

print("Data Loader will be saved to {}".format(save_name))

torch.save(data_loader, save_name)

#xxx.write("8\n")
#xxx.flush()

