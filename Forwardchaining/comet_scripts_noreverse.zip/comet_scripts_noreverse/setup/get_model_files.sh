git clone https://github.com/openai/finetune-transformer-lm.git
mv finetune-transformer-lm/model .
rm -rf finetune-transformer-lm